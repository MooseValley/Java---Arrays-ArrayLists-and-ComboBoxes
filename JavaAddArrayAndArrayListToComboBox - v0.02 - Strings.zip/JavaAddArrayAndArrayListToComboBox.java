import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.ArrayList;


public class JavaAddArrayAndArrayListToComboBox extends JFrame
{
   private JLabel    arrayLabel                  = new JLabel ("Array Combobox: ");
   private JComboBox<String>  arrayComboBox      = new JComboBox<String> ();

   private JLabel    arrayListLabel              = new JLabel ("ArrayList Combobox: ");
   private JComboBox<String> arrayListComboBox   = new JComboBox<String> ();

   private JButton getComboBoxSelectionsButton   = new JButton ("Get ComboBox Selections");
   private JLabel  arrayOutputLabel              = new JLabel ("");
   private JLabel  arrayListOutputLabel          = new JLabel ("");



   public JavaAddArrayAndArrayListToComboBox ()
   {
      JPanel panel1 = new JPanel (new FlowLayout (FlowLayout.CENTER) );
      JPanel panel2 = new JPanel (new FlowLayout (FlowLayout.CENTER) );
      JPanel panel3 = new JPanel (new FlowLayout (FlowLayout.CENTER) );

      // Build a basic GUI

      panel1.add (arrayLabel);
      panel1.add (arrayComboBox);

      panel2.add (arrayListLabel);
      panel2.add (arrayListComboBox);

      panel3.add (getComboBoxSelectionsButton);

      setLayout (new GridLayout (5, 1) );  // R,C
      add (panel1);
      add (panel2);
      add (panel3);
      add (arrayOutputLabel);
      add (arrayListOutputLabel);

      getComboBoxSelectionsButton.addActionListener (event -> getComboBoxSelections() );

      // Populate the namesArray and arrayComboBox
      String[] namesArray = {"Moose", "Frankie", "Bella", "Teenie Weenie"};

      for (int k = 0; k < namesArray.length; k++)
      {
         arrayComboBox.addItem (namesArray [k]);
      }


      // Populate the namesArrayList and arrayListComboBox
      ArrayList<String> namesArrayList = new ArrayList<String> ();
      namesArrayList.add ("Samuel");
      namesArrayList.add ("Ben");
      namesArrayList.add ("Boogle");

      for (int k = 0; k < namesArrayList.size(); k++)
      {
         arrayListComboBox.addItem (namesArrayList.get(k));
      }

   }

   private void getComboBoxSelections()
   {
      arrayOutputLabel.setText ("Selected arrayComboBox: " +
          arrayComboBox.getSelectedIndex () + ": " +
          arrayComboBox.getSelectedItem () );

      arrayListOutputLabel.setText ("Selected arrayListComboBox: " +
          arrayListComboBox.getSelectedIndex () + ": " +
          arrayListComboBox.getSelectedItem () );

   }


   public static void main (String[] args)
   {
      JavaAddArrayAndArrayListToComboBox app = new JavaAddArrayAndArrayListToComboBox ();

      app.setTitle ("Java - Add Array and ArrayList to ComboBox");
      app.setSize  (600, 300);
      app.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      app.setVisible (true);
   }
}
