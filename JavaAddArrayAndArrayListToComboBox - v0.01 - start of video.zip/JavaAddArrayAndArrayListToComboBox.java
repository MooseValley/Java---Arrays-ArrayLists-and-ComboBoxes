import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.ArrayList;


public class JavaAddArrayAndArrayListToComboBox extends JFrame
{
   private JLabel    arrayLabel                  = new JLabel ("Array Combobox: ");
   private JComboBox arrayComboBox               = new JComboBox ();

   private JLabel    arrayListLabel              = new JLabel ("ArrayList Combobox: ");
   private JComboBox arrayListComboBox           = new JComboBox ();

   private JButton getComboBoxSelectionsButton   = new JButton ("Get ComboBox Selections");


   public JavaAddArrayAndArrayListToComboBox ()
   {

   }


   public static void main (String[] args)
   {
      JavaAddArrayAndArrayListToComboBox app = new JavaAddArrayAndArrayListToComboBox ();

      app.setTitle ("Java - Add Array and ArrayList to ComboBox");
      app.setSize  (900, 600);
      app.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
      app.setVisible (true);
   }
}
